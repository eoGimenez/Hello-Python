search = 10

for number in range(5):
    print(number)
    if number == search:
        print(f"encontrado {search}")
        break
else:
    print("no encontre el número")


# las strings tambien son iterables
for char in "Ultimate Python":
    print(char)
