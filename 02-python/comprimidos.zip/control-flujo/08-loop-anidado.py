for j in range(3):  # auter for/loop
    for k in range(2):  # inner for/loop
        print(f"{j}, {k}")
