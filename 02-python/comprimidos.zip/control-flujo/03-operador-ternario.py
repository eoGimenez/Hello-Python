age = 19

message = "Es mayor" if age > 17 else "Es menor"

print(message)
