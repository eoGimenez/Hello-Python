# and, or, not

gas = True
on = False
age = 18

message = "Puedes avanzar" if gas and (
    not on or age > 17) else "No puedes avanzar"
message_two = "Puedes avanzar" if not gas or not on else "No puedes avanzar"


print(message)
print(message_two)
