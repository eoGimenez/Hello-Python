# hay número ? sino hay que ingresar:
# ingrese operación,
# otro numero.
# mostrar resultado y lo asigna al primero numero y empieza desde operacion

print("""Bienvenidos a la calculadora
Para salir escribe salir
Las operaciner son: suma, resta, multi, div""")


num_one = 0
num_two = 0
command = ""


while command.lower() != "salir":
    if not num_one:
        num_one = input("Ingrese número: ")
        num_one = int(num_one)
    else:
        print(f"El resultado es: {num_one}")
        command = input("Infrese operación: ")
        if command.lower() == "salir":
            break
        num_two = input("Ingrese segundo número: ")
        num_two = int(num_two)
        if command.lower() == "suma":
            num_one += num_two
        if command.lower() == "resta":
            num_one -= num_two
        if command.lower() == "multi":
            num_one *= num_two
        if command.lower() == "div":
            num_one /= num_two
