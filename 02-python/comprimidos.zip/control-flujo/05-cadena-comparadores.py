age = 65

# usamos la primer comparacion como parametro de corto circuito y aprovechamos la variable para compararla con la segunda condicion !
message = "Puede entrar" if 15 <= age <= 65 else "No puede entrar"

print(message)
