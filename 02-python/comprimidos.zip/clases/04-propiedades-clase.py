class Perro:
    patas = 4  # propiedad de clase, fija para todas las instancias por igual

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def habla(self):
        print(f"{self.name} dice, Guau!")


mi_perro_dos = Perro("chicih", 1)
# Aquí cambiamos el atributo de la clase general, cambiara todas las clases, previas y posterirores.
Perro.patas = 3
mi_perro = Perro("Curry", 2)
# cuando cambiamos un atributo de clase de una instancia cambia solo para esa instancias
mi_perro.patas = 5
print(Perro.patas)
print(mi_perro.patas)
print(mi_perro_dos.patas)
