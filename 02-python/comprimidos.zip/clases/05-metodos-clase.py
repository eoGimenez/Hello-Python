class Perro:
    patas = 4

    def __init__(self, name, age):
        self.name = name
        self.age = age

    @classmethod  # es la forma de hacer un metodo de la clase misma
    def habla(cls):
        print("Guau!")

    # Factory method - es un método para crear instancias por defecto
    @classmethod
    def factory(cls):
        return cls("Chancho", 4)  # cls es para llamar a Perro()


Perro.habla()  # asi una clase llama a sus propios métodos
perrito = Perro("Curry", 2)
perrito2 = Perro("efiwf", 1)
perrito3 = Perro.factory()

print(perrito3.age, perrito3.name)
