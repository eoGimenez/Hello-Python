class Perro:
    def __init__(self, name):
        self.name = name

    @property  # para "transformar" un método en un atributo visualmente
    def name(self):  # solo se usa en GETTERS, le quitamos el "get_"
        print("pasando por getter")
        return self.__name

    @name.setter  # este decorador lo crea el primer property y es par asignarlo si queremos dar la opcion de modificar un atributo
    def name(self, name):
        print("pasando por Setter")
        if name.strip():
            self.__name = name
        return


perrito = Perro("asdasd")
print(perrito.name)
perrito.name = "Curry"
print(perrito.name)
