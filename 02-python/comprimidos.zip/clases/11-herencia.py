class Animal:
    def comer(self):
        print("comiendo")


class Perro(Animal):  # Hereda todo de la clase Animal
    def pasear(self):
        print("paseando")


class Chanchito(Perro):  # Hereda todo lo de Perro y todo Lo que haya heredado Perro
    def programar(self):
        print("programando")
# Las Herencias en cadena son peligrosas, evitar hacer mas de dos escalones
# en un momento determinado querremos cambiar algo de una herencia y cambiara para todos


perrito = Perro()

perrito.comer()
perrito.pasear()

chanchito = Chanchito()
chanchito.comer()
chanchito.pasear()
chanchito.programar()
