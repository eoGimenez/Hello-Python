from abc import ABC, abstractmethod


class Model(ABC):
    @abstractmethod  # nos aseguramos que tengan que tener este método
    # pero no necesariamente hagan todos los hijos lo mismo.
    def guardar(self):
        pass


class User(Model):
    def guardar(self):
        print("Guardando en BBDD")


class Session(Model):
    def guardar(self):
        print("Guardando en Archivo")

# las condiciones es que se les pase una lista y tengan el método de guardar()


def guardar(entidades):  # Creamnos una funcion que ejecute la funcion similar de cada objeto,
    for entidad in entidades:
        entidad.guardar()


# la condicion es que tengan guardar
pepito = User()
new_session = Session()

guardar([pepito, new_session])


# Duck Typing es que la funcion guardar([]) no se fija si lo que le estas pasando como parametro
# es un modelo o no,
