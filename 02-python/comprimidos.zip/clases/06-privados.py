class Perro:
    def __init__(self, name, age):
        # atributo privado, una vez asignado ya no de puede modificar, salvo con un método de la clase
        self.__name = name
        self.age = age

    def habla(self):
        print(f"{self.__name} dice, Guau!")

    def get_name(self):
        # asi podemos leer este atributo pero nunca modificarlo.
        return self.__name
# tambien se pueden crear métodos privados

    def set_name(self):
        return self.__name

    @classmethod
    def factory(cls):
        return cls("Curry", 4)
# VS code Ctrl + shift + P , rename symbol


perrito = Perro.factory()
perrito.habla()
# print(perrito.__name) como ese atributo es privado ya no podemos usarlo desde fuera, solo podrmos mediante un método
print(perrito.get_name())


# para cambiar una propiedad sin metodo: EVITAR HACER ESTO!
# perrito._Perro__name = "Nopla"
# print(perrito.get_name())
