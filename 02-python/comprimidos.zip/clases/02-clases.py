class Perro:  # para clases se usa camelcase
    def habla(self):  # En los métodos SIEMPRE VA A IR CON "self"
        print("Guau!")


mi_perro = Perro()
mi_perro.habla()
# Para ver si un Objeto es una instancia de la clase que le pasamos
print(isinstance(mi_perro, Perro))
