class Animal:
    def comer(self):
        print("comiendo")

    def pasear(self):
        print("paseando Animales !")


class Caminador:
    def caminar(self):
        print("caminando")


class Volador:
    def volar(self):
        print("volando")


class Nadador:
    def nadar(self):
        print("nadando")


class Perro:
    def pasear(self):
        print("paseando al perro")

#                 2      1   toma primero los metodos de la derecha y luego remplaza con los de la izquierda
class Chanchito(Perro, Animal):  # Herencia multiple
    def programar(self):
        print("programando")


class Pato(Nadador, Caminador, Volador):
    def hablar(self):
        print("Cuack!")


chanchito = Chanchito()
chanchito.comer()
chanchito.pasear()
chanchito.programar()


# regla de Herencia multiple, el método que se encuentre duplicado con otra clase,
# lo vamos a eliminar y las clases para herencias multiples que sena los mas pequeñas posibles
