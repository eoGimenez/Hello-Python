class Model():
    table = False

    def __init__(self):
        if not self.table:
            print("Error tienes que definir una tabla")

    def guardar(self):
        print(f"Guardando usuario en la tabla de {self.table} en BBDD")

    @classmethod
    def get_user(self, _id):
        print(f"Buscando por id {_id} en la tabla de {self.table}")


class User(Model):
    table = "Users"


pepito = User()

pepito.guardar()
User.get_user(123)
