class Listaa(list):  # extendes los tipos nativos y armas métodos customs
    def agregar_inicio(self, item):
        self.insert(0, item)


testeando = Listaa([1, 2, 3])

testeando.append(4)
testeando.agregar_inicio("NO LA PODES CREER")
print(testeando)
