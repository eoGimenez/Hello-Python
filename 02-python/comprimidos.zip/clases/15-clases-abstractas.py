from abc import ABC, abstractmethod
# ABC es la class que tenemos que heredar de Abstract Class
# abstractmethod para las propiedades y métodos


class Model(ABC):  # de esta forma ya no se pueden crear instancias de Model
    @property
    @abstractmethod  # al heredar obligamos a crear la propiedad Tabla
    def table(self):
        pass

    @abstractmethod  # si quisieramos tener algun otro método abstracto.
    def guardar(self):
        pass

    @classmethod
    def get_user(self, _id):
        print(f"Buscando por id {_id} en la tabla de {self.table}")


class User(Model):
    table = "Users"

    def guardar(self):
        print("Guardando usuario")


pepito = User()

pepito.guardar()
User.get_user(123)
