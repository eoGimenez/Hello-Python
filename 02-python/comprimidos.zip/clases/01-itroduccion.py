string = "HOla la la"
print(type(string))

# Clase: es el plano de construcción
# Objeto: una instancia de una clase

# Clases: el plano de construcción de una cas
# Objeto: la casa construída

# Clase: Humano
# Objeto: Nicolas, Eugenio, Julieta....
