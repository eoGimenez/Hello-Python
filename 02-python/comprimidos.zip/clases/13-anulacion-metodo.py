class Ave:
    def __init__(self):
        self.volador = True

    def volar(self):
        print("vuela ave")


class Pato(Ave):
    def __init__(self):
        super().__init__()  # asi ejecutamos el constructor de la clase padre
        self.nadador = True

    def volar(self):  # re-definiendo el método en la sub-clase con el mismo nombre que en la clase la sobre escribe
        super().volar()  # da acceso inmediato a todos los atributos y métodos de la clase padre
        print("vuela pato")


patito = Pato()
patito.volar()
print(patito.volador, patito.nadador)
