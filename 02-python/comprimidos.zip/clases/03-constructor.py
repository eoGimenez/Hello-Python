class Perro:  # __init__ es el constructor
    def __init__(self, name, age):  # self es como el this, siempre hace referencia a la instancia
        self.name = name
        self.age = age

    def habla(self):
        print(f"{self.name} dice, Guau!")


mi_perro = Perro("Curry", 2)
print(mi_perro.name)
