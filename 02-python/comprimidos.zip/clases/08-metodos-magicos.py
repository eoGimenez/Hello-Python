class Perro:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __del__(self):
        print(f"Chau perrito {self.name}")

    def habla(self):
        print(f"{self.name} dice, Guau!")

    def __str__(self):
        return f"Clase Perro: {self.name}"

# documentacion "magic methods python"
# github: A guide to python's de "rszalski.github.io"


perrito = Perro("fwefwf", 1)

del perrito

# Método mágico Destructor !
