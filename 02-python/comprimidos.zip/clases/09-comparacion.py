class Coordenadas:
    def __init__(self, lat, lon):
        self.lat = lat
        self.lon = lon

    def __eq__(self, other):  # compara con otro, con este ya devuelve tambien en la consulta negativa " != "
        return self.lat == other.lat and self.lon == other.lon

    # def __ne__(self, other): No Equal
    #     return self.lat != other.lat or self.lon != other.lon

    # def __lt__(self, other):
    #     return self.lat + self.lon < other.lat + other.lon

    def __le__(self, other):  # menor o igual, de esta forma cubrimos las 3 opciones, < - > - >=
        return self.lat + self.lon <= other.lat + other.lon


coords_one = Coordenadas(23, 15)
coords_two = Coordenadas(22, 15)
coords_tree = coords_two

# print(coords_one == coords_two)
# print(coords_one != coords_two)
print(coords_one >= coords_two)
