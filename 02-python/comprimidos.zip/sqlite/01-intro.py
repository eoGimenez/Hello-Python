import sqlite3

con = sqlite3.connect("sqlite/app.db")
con.close()  # siempre hay que cerrar la DB, para poder seguir usando la DB
