import sqlite3

with sqlite3.connect(r"sqlite\app.db") as con:
    cursor = con.cursor()
    users = [
        (2, "Julieta"),
        (3, "Euge"),
        (4, "Carrot"),
    ]
    cursor.executemany(
        "INSERT INTO usuarios values(?, ?)",
        users
    )
