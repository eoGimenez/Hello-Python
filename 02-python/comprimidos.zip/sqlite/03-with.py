import sqlite3

# el operador "WITH", cuando sale del dentado, llama a commit() y luego al método mágico __exit__
# que en sqlite están los dos precentes, por ello si lo usamos con otra DB hay que mirar si tiene el método mágico !

with sqlite3.connect("sqlite/app.db") as con:
    cursor = con.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS usuarios(
        id INTEGER PRIMARY key,
        name VARCHAR(50))
        """
    )
