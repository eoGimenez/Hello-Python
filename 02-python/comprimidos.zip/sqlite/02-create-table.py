import sqlite3

con = sqlite3.connect("sqlite/app.db")
# cursor, es el interprete entre la DB y la app, con el que crearemos consultas
cursor = con.cursor()
cursor.execute(
    """
    CREATE TABLE if not exists usuarios
    (id INTEGER primary key, name VARCHAR(50))
    """
)  # si no hacemos commit(), la DB no levanta los datos
con.commit()  # si o si, despues de generar la consulta.
con.close()
