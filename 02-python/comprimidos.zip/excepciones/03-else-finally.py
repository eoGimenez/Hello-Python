try:
    n1 = int(input("Ingrese primer número: "))
except Exception as e:
    print("Ocurrió un error")
else:
    # cuando no existán errores y te quieras mantener dentro del contexto del try/catch.
    print("No ocurrió ningún error")
finally:
    print("Se ejecuta siempre")  # se ejecuta siempre
