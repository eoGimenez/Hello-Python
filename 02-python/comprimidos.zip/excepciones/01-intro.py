try:
    n1 = int(input("Ingrese primer número: "))
except:
    print("Ocurrió un error =/")
