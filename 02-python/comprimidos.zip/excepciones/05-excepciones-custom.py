class MyError(Exception): # errores customs
    "Esta clase es para representar mi error"

    def __init__(self, message, code):
        self.message = message
        self.code = code

    def __str__(self):
        return f"{self.message} - Codigo Error: {self.code}"


def division(n=0):
    if n == 0:
        raise MyError("No se puede dividir por 0", 8002)
    return 5 / n


try:
    division()
except MyError as e:
    print(e)
