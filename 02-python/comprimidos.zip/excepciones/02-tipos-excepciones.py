try:
    n1 = int(input("Ingrese primer número: "))
    owne
except ValueError as e:
    print("Ingrese un valor que corresponda!")
except NameError as e:
    print("Ocurrió un error")
