"""Introducción a Python"""

print("hola mundo!")
print('El weta ' * 4)
