import requests

r = requests.get("https://www.google.com.co")
print(r)
