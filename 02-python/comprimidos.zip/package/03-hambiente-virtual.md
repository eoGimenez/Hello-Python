python -m venv env


# para activcar


env\scripts\activate.ps1

# si da error el hambiente virtual

set-executionpolicy RemoteSigned 

