# --user, por que no anda esto bien.

pip install requests

# para especificar versiones en particular:

pip install requests==2.18.1

# eliminar
pip uninstall requests

# update

# la ultima disponible dentro de la 18 ( en este caso )

pip install requests==2.18.*
pip install requests~=2.18.1

#


pip list
