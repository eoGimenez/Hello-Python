def suma(*numbers):
    total = 0
    for num in numbers:
        total += num
    print(total)


suma(2, 5, 5, 6 ,34)
