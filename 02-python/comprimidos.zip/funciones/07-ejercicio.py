# def es_palindromo(text):
#     return text.lower().replace(" ", "") == text[::-1].lower().replace(" ", "")


# print("Abba", es_palindromo("fwweg"))
def empty_spaces(text):
    text_space = ""
    for char in text:
        if char != " ":
            text_space += char
    return text_space


def es_palindromo(text):
    text = empty_spaces(text)
    text_aux = ""
    for i in range(0, len(text)):
        text_aux += text[-i - 1]
    return text.lower() == text_aux.lower()


print("Amo la paloma", es_palindromo("Amo la paloma"))
