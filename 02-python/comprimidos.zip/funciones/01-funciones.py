def hola(name, surname="Pre-setted"):
    print("Hola Mundo!")
    print(f"Binevenido {name} {surname}")


hola("Eugenio", "Giménez")
hola("Nico")


hola(surname="Gonzales", name="Lucas")
