saludo = "HOLA"


def saludar():
    # global saludo la palabra reservada "global" es para que la función tome una variable
    # de alcance global, es UNA MALA PRACTICA LAS VARIABLES TIENE QUE TENER SIEMPRE SCOPE
    saludo = "Hola Mundo"
    print(saludo)


def saluda_chanchito():
    saludo = "Hola chanchito"
    print(saludo)


saludar()
print(saludo)
