def no_space(text):
    new_text = ""
    for char in text:
        if char != " ":
            new_text += char
    return new_text


def reverse(text):
    text_inve = ""
    for char in text:
        text_inve = char + text_inve
    return text_inve


def es_palindromo(text):
    text = no_space(text)
    text_invert = reverse(text)
    return text.lower() == text_invert.lower()


# no olvidarse de usar funciones que usan funciones, 
# evitar funciones anidadas