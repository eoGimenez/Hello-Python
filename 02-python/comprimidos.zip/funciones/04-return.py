def suma(a, b):
    return a + b


result = suma(2, 5)
result_dos = suma(result, 5)

print(result)
print(result_dos)
