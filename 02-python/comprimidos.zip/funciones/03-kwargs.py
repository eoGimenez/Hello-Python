def get_product(**datos):  # dos asteriscos para iterar con nombres de parametros,
    print(datos["id"], datos["name"])


get_product(id=20, name="iphone", desc="Telefono")

# es para trabajar con diccionarios
