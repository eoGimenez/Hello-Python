# para remarcar mostrar comillas dentro de una string hay que usar las
# comillas contrarias a la string, o enserrarlos entre backslashs
curso = "Ultimate \n\"Python\""
curso_back = "Ultimate 'Python'"
print(curso)
print(curso_back)

# \n va a hacer saltos de linea
