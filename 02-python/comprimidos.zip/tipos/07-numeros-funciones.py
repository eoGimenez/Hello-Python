import math

# devuelve el número al que se encuentre mas cercano,
print(round(1.49))  # de 1.01 a 1.49 =  devuelve 1
print(round(1.7))  # desde 1.49 a 1.99 = devuelve 2
# devuelve 1.71, el segundo param es para ver cuantos decimales dejamos
print(round(1.712786, 2))
# devuelve el valor absoluto de lo que pasemos al método
print(abs(-77))  # devuelve 77
# toma el argumento y lo transforma al número entero numeor más cercano hacia el techo
print(math.ceil(1.1))  # devuelve = 2
# toma el argumento y lo transforma al número entero más cercano hacia abajo
print(math.floor(1.9))  # devuevle 1
# mira si el valor de lo que le estemos pasando NO  es un número
print(math.isnan(23))  # false, porque es un número
# print(math.isnan("23")) da error porque espera un número
# Eleva un número a la potencia de algo, primero argumento elevado al valor del segundo argumento
print(math.pow(10, 3))  # devuelve float
# calcula la raíz cuadrada del argumento que le pasemos
print(math.sqrt(9))  # devuelve un float
