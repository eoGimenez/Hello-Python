nombre_curso = "Ultimate Python"
descripcion_curso = """
este curso contempla todos los detalles que necesitas 
aprender para conseguir un trabajo de programador.
"""

print(len(nombre_curso))
print(nombre_curso[0])
# print(nombre_curso[index de inicio:index de cuantos caracterer quiero recortar])
print(nombre_curso[0:8])
# print(nombre_curso[si no tiene nada inicia en 0:si no tiene index llega al final del string])
print(nombre_curso[9:])
print(nombre_curso[:8])  # idem linea 10
print(nombre_curso[:])  # todo el String
