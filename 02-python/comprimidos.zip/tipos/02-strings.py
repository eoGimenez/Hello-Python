nombre_curso = "Ultimate Python"
descripcion_curso = """
este curso contempla todos los detalles que necesitas 
aprender para conseguir un trabajo de programador.
"""

# primer valor el char a buscar, segundo inicio de la busqueda, tercero fin busqueda sin incluir ( como siempre )
print(descripcion_curso.index("c", 10, 13))
print(descripcion_curso.rindex("c")) # del fin al pincipio
print(len(nombre_curso))
print(nombre_curso[0])
# print(nombre_curso[index de inicio:index de cuantos caracterer quiero recortar])
print(nombre_curso[0:8])
# print(nombre_curso[si no tiene nada inicia en 0:si no tiene index llega al final del string])
print(nombre_curso[9:])
print(nombre_curso[:8])  # idem linea 10
print(nombre_curso[:])  # todo el String
print(descripcion_curso[::-1]) #da vuelta la cadena
