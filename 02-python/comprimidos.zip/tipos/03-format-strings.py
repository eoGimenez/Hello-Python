name = "Eugenio"
surname = "Giménez"
full_name = f"{name} {surname}"
# Dentro de las llaves se puede poner la expresión que querramos, no solo variables
full_name = f"{name[0]} {2 + 8}"
print(full_name)
