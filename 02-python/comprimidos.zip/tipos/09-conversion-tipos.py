# int()
# str()
# float()
# bool()
# falsy = str vacio, 0 (cero), None o lista vacia
# truthy = todo lo que no es falsy

print(bool(""))  # False
print(bool("0"))  # True
print(bool(None))  # False
print(bool(0))  # False
print(bool(" "))  # True
print(bool([]))  # False
