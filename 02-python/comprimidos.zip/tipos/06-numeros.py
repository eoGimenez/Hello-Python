number = 2  # int
decimal = 1.2  # float
imaginario = 2 + 2j  # 2 + 2i

number += 2  # se puede hacer con + , - , / , *

print(1 + 3)
print(1 - 3)
print(1 * 3)
print(3 / 3)  # devuelve floar
print(3 // 3)  # devuelve int
print(8 % 3)  # modulo de siemrpe xD
print(2 ** 3)  # elevado
