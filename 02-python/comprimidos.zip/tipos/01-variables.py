"""01_variables"""

nombre_curso = "Ultimate Python"
NOMBRE_CURSO = "Hola"
print(nombre_curso, NOMBRE_CURSO)
