animal = "  chanCHito feliz     "
# toma el string de la variable y la transforma a mayus
print(animal.upper())
# las transforma en minusculas
print(animal.lower())
# Toma el primer caracter y lo transforma en mayus, y todo el resto en minuscula
print(animal.strip().capitalize())
# Toma la primera letra de cada palabra y las pasa a mayusculas,
# Si tiene espacios, el método capitalize() no funcionara
print(animal.title())
# remueve todo lo que tengas dentro de los parentesis,
# enmpezando del [0] hasta encontrar uno que no esta en la regal y se va al
# [-1] hasta encontrar otro caracter que no ese en la regla
print(animal.strip())
# busca el argumento y devuelve el index, si devuleve -1 es que no lo encontró
print(animal.find("cH"))
# si no encunetra no hace nada, si encuentra lo remplaza, primer str : busqueda, segun str: remplazo
print(animal.replace("nCH", "j"))
# busca si el string está en la variable en boolean
print("nCH" in animal)
# busca si NO se encuentra en el string en boolean
print("nCH" not in animal)
