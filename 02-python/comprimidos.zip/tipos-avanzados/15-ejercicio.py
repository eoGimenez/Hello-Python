# 1. eliminar espacios haciendo comprencion de lista y
# deovlver los caracters restantes

# 6- juntar la solucion de los ejercicos anteriores para
# encontra los caracteres que mas se repiden de un string

string = "Hola mundo, estoy aca haciendo ejercicios"
string_aux = ""
array = list(string)
array_fiter = [char for char in array if char != " "]
# print(array_mapped)
for char in array_fiter:
    string_aux += char
# 2. contar en un diccionario cunatos caracteres se reiten
# en una string

diccionary = {}

for char in string_aux.lower():
    if char in diccionary:
        diccionary[char] = diccionary[char] + 1
    else:
        diccionary[char] = 1
# print("diccionario 1", diccionary)

# 3. ordenar las llaves de un diccionario y devolver una lista que contenga tuplas

array_tup = []

for char in diccionary.items():
    if not array_tup:
        array_tup.append(char)
    else:
        print(char)
        for i, order in enumerate(array_tup):
            if char[1] >= order[1]:
                print("QUE ES ESTO", char, order)
                array_tup.insert(i, char)
                break
            if char[1] < order[1]:
                continue
            array_tup.append(char)

print("ORDENADA", array_tup)

# 4 de un listado de tuplas, devolver las tuplas con mayor valor
# los caracteres que mas se repiten con 4 repeticiones son_
# - C
# - D

biggest = []
for value in array_tup:
    if not biggest:
        biggest.append(value)
    elif value[1] == biggest[0][1]:
        biggest.append(value)
    elif value[1] > biggest[0][1]:
        del biggest[0]
        biggest.append(value)
print(f"""
Los caracteres que más se repiten con {biggest[0][1]} repeticiones son:
-{str(biggest[0][0]).upper}
""")
