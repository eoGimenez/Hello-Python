numbers = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["chanchito", "feliz"]
palabras_felices = ["chanchito", "feliz", "Felipe", "alumnos"]
booleans = [True, False, False, True]
matriz = [[0, 1], [1, 0]]  # listado que contiene más listados
ceros = [0] * 10
alfanumerico = numbers + letras
rango = list(range(1, 11))
chars = list("Hola Mundo")
print(chars)
