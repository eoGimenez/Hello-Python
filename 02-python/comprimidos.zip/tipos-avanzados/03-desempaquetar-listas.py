numbers = [1, 2, 3]

primero, segundo, tercer = numbers
print(primero, segundo, tercer)
numbers = [1, 2, 3, 4, 5, 6]
n1, *others, last_one = numbers
print(n1, others, last_one)
