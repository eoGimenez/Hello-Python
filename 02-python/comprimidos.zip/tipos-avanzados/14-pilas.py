pila = []
pila.append(1)
pila.append(2)
pila.append(3)
print(pila)
last_one = pila.pop()
last_one = pila.pop()
last_one = pila.pop()
print(last_one)
print(pila)

if not pila:
    print("Pila vacia")