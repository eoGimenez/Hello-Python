numbers = (1, 2, 3) + (4, 5, 6)
print(numbers)


punto = tuple([1, 2])
print(punto)

# cuando desempaquetamos restos "*otros" se hace una lista
primero, segundo, *otros = numbers
print(primero, segundo, otros)
