numbers = [2, 55, 4, 32, 12, 3, 6, 8]

numbers.sort()  # ascendente
print(numbers)
numbers.sort(reverse=True)  # descendente
print(numbers)

new_list = sorted(numbers, reverse=True)  # ordena y devuelve una nueva lista
print(new_list)

users = [
    ["Carrot", 1],
    ["Chanchito", 5],
    ["Pulga", 3],
    ["Curry", 2]
]
# para ordenar listas matrices, solo funcionara el sort si el primer elemento de cada lista es ordenable
# si no hay que hacer una funcion para pasarsela a .sort("FUNCION")


""" 
cuando usamos una funcion tan especifica es
mas prolijo pasar una funcion lambda

def ordenar(elem):
    return elem[1]
 """
users.sort(key=lambda elem: elem[1])
print(users)
