users = [
    ["Carrot", 1],
    ["Chanchito", 5],
    ["Pulga", 3],
    ["Curry", 2]
]

# name = [expresión for item in items]
# en este caso la expresión es para conseguir el primer elemento transforma
# map
name = [user[0] for user in users]
# filter
name_two = [user for user in users if user[1] > 2]
# filtrada y transformada
name_tree = [user[0] for user in users if user[1] > 2]
print(name)
print(name_two)
print(name_tree)

nombres = list(map(lambda user: user[0], users))
print(nombres)
menos_nombres = list(filter(lambda user: user[1] > 2, users))
print(menos_nombres)
