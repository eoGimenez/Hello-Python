pets = ["Pelusa", "Carrot", "Felipe", "Chanchito", "Carrot", "Wolfgang"]

print(pets.count("Carrot"))  # devuelve cuantas coincidencias,
if "Carrot" in pets:
    print(pets.index("Carrot"))
