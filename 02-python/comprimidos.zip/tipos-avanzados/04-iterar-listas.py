pets = ["Pelusa", "Pulga", "Felipe", "Chanchito", "Carrot"]


# enumerate() devuelve una tupla por cada elemento de la lista, con un index
for i, pet in enumerate(pets):
    print(i, pet)
