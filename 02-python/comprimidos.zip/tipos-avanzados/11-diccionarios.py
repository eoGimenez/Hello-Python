punto = {"x": 25, "y": 50}
print(punto)
print("que tenemos aca",punto["x"])  # para acceder a los valores de las keys

punto["z"] = 45  # creamos nueva key

print(punto)

if "lala" in punto:
    print("encontré a LALA", punto["lala"])

print(punto.get("x"))  # conseguimos el valor de la key pedoda
# el segundo es el valor por defencto para evitar el "None"
print(punto.get("lala", 97))
del punto["x"]  # elimina una key y su valor
del (punto["y"])  # elimina una key y su valor ESTA ES UNA FUNCION
print(punto)

punto["x"] = 25

for key in punto:  # para recuperar los valores y las key, aunque es poco estetico
    print(key, punto[key])

for valor in punto.items():  # metodo items() devuelve tuplas
    print(valor)

for llave, valor in punto.items():  # para desempaquetar en el for
    print("tercer ",llave, valor)

users = [
    {"id": 1, "name": "Carrot"},
    {"id": 2, "name": "Curry"},
    {"id": 3, "name": "Felipe"},
    {"id": 4, "name": "Pelusa"},
]

for user in users:
    print(user["name"])
