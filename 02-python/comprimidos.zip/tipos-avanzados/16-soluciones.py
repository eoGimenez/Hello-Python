from pprint import pprint

string = "Hola mundo, estoy aca haciendo ejercicios"


def spaces(text):
    return [char.lower() for char in text if char != " "]


def counter(lista):
    chars_dict = {}
    for char in lista:
        if char in chars_dict:
            chars_dict[char] += 1
        else:
            chars_dict[char] = 1
    return chars_dict


def ordenar(dict):
    return sorted(
        dict.items(),
        key=lambda key: key[1],
        reverse=True
    )


def mayores_tuplas(lista):
    max_val = lista[0][1]
    respons = {}
    for order in lista:
        if max_val > order[1]:
            break
        respons[order[0]] = order[1]
    return respons


def new_message(diccionario):
    message = "Los que más se repiten son: \n"
    for key, valor in diccionario.items():
        message += f"- {key} con {valor} repeticiones \n"
    return message


sin_espacios = spaces(string)
contados = counter(sin_espacios)
ordenados = ordenar(contados)
mayores = mayores_tuplas(ordenados)
mensaje = new_message(mayores)


pprint(mensaje)
