pets = ["Pelusa", "Pulga", "Felipe",
        "Chanchito", "Carrot", "Pulga", "Wolfgang"]

pets.insert(1, "Curry")
pets.append("Titi")  # Agrega al final

pets.remove("Pulga")  # Elimina el primero
pets.pop()  # elimina el iltimo, si pasamos Index elimina el del Inidice
del pets[0]  # igual que Pop
print(pets)

pets.clear() # Vacia la lista
print(pets)
