# * operador de desempaquetador de listas y tuplas

lista = [1, 2, 3, 4]
print(*lista)

lista_dos = [5, 6]

combinada = ["HOla", *lista, "mundo",  *lista_dos, "Carrot"]

print(combinada)

# ** operador de desempaquetado de diccionarios
punto_uno = {"x": 12, "y": "Hola"}
punto_dos = {"y": 16}
# primero asigna el operador de desempaquetamiento
new_punto = {**punto_uno,"lala": "hola mundo", **punto_dos, "z": 20} # escribe de derecha a izquierda

print(new_punto)
