# set son grupos o conjuntos
primer = {1, 1, 2, 2, 3, 4}  # no guarda duplicados
print(primer)
# primer.add(5)
# primer.remove(1)
# print(primer)

second = [3, 4, 5]
second = set(second)

# | une sets
print(primer | second)
# & intersección elementos que se encuentren en los dos sets
print(primer & second)
# - diferencia muestra solo los datos de la izquierda y quita los de la derecha.
print(primer - second)
# ^ diferencia simetrica, devuelve los que no esten repetidos en los dos sets
print(primer ^ second)

if 5 in second:
    print("Hola")