pets = ["Wolfgang", "Pelusa", "Pulga", "Copito", "Carrot", "Curry"]
print(pets)
pets[0] = "Bicho"
print("Elemento [0] modificado, ", pets)
# print(pets[index de inicio:index de fin]:int de saltos)
print(pets[2:])
print(pets[::2])


numbers = list(range(21))
print(numbers[::2])
print(numbers[1::2])
