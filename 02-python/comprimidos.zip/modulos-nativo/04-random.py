import random
import string

lista = [1, 2, 3, 4, 5, 6, 7, 8]
lista_dos = [1, 2, 3, 4, 5, 6, 7, 8]
random.shuffle(lista)

print(
    random.random(),
    random.randint(1, 10),
    lista,
    random.choice(lista_dos),
    random.choices(lista_dos, k=3),
    "".join(random.choices("abcdefgh..d,dw,`", k=3)),
)

# para generar contraseñas aleatoreas:


chars = string.ascii_letters
digits = string.digits
password = "".join(random.choices(chars + digits, k=16))

print(password)
