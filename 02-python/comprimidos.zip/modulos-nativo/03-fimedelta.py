from datetime import datetime, timedelta


fecha = datetime(2023, 1, 1) + timedelta(weeks=1)
fecha_dos = datetime(2023, 2, 1)

delta = fecha_dos - fecha

print(delta)
print("dias", delta.days)
print("segundos", delta.seconds)
print("microsegundos", delta.microseconds)
print("total_sconds ()", delta.total_seconds())
