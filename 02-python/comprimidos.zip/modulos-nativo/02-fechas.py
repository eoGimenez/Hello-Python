# import time

# # timestamp: segundos desde el 1 de enero de 1970 con respecto a UTC
# print(time.time())

from datetime import datetime

fecha = datetime(2023, 1, 1)
fecha_dos = datetime(2023, 2, 1)

ahora = datetime.now()


# directivas google " python 3 strptime directives "
fecha_str = datetime.strptime("2023-01-03", "%Y-%m-%d")
print(fecha.strftime("%Y.%m.%d"))

print(fecha > fecha_dos)

print(
    fecha.year,
    fecha.month,
    fecha.day,
)
