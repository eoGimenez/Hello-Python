import json
from pathlib import Path

# escribir un JSON

# products = [
#     {"id": 1, "name": "Surfboard"},
#     {"id": 2, "name": "Bike"},
#     {"id": 3, "name": "Skate"},
# ]

# data = json.dumps(products)
# Path("archivos/products.json").write_text(data)

# leer JSON

data = Path("archivos/products.json").read_text(encoding="utf-8")
products = json.loads(data)

# modificar JSON

products[0]["name"] = "Surf"
data = json.dumps(products)
Path("archivos/products.json").write_text(data, "utf-8")
