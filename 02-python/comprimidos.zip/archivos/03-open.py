from io import open

# escritura

# texto = "Hola mundito"

# archivo = open("archivos/hola-mundo.txt", "w")
# archivo.write(texto)
# archivo.close()


# Lectura

# archivo = open("archivos/hola-mundo.txt", "r")
# text = archivo.read()
# archivo.close()
# print(text)

# lectura como lista

# archivo = open("archivos/hola-mundo.txt", "r")
# text = archivo.readlines()
# archivo.close()
# print(text)

# with y seek

# with open("archivos/hola-mundo.txt", "r") as archivo:
#     print(archivo.readlines())
#     archivo.seek(0)  # indicamos que el puntero se mueva al caracter indicado
#     for linea in archivo:
#         print(linea)


# agregar

# archivo = open("archivos/hola-mundo.txt", "a+")
# archivo.write("Chau mundo: /")
# archivo.close()


# lectura y escritura

# with open("archivos/hola-mundo.txt", "r+") as archivo:
#     text = archivo.readlines()
#     archivo.seek(0)
#     text[0] = "Carrot feliz !!"
#     archivo.writelines(text)
