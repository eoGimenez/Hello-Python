from pathlib import Path
from zipfile import ZipFile

# Escritura / creación

with ZipFile("archivos/comprimidos.zip", "w") as zip:
    for path in Path().rglob("*.*"):
        if str(path) != r"archivos\comprimidos.zip":
            zip.write(path)

# Lectura

# with ZipFile("archivos/comprimidos.zip") as zip:
#     # print(zip.namelist())
#     info = zip.getinfo("archivos/06-comprimidos.py")
#     print(
#         info.file_size,
#         info.compress_size,
#     )
#     zip.extractall("archivos/descomprimidos")
