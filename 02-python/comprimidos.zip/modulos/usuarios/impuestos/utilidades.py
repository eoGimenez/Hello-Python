if __name__ != "__main__":  # generamos un condicional para importar si no esta ejecutando de __main__
    from ..gestion.crud import guardar  # <<< este es un import relativo
    # from usuarios.gestion.crud import guardar <<< este es un import absoluto

    print(__name__)

    def pagar_impuestos():
        print("Pagando impuestos =(")
        guardar()


if __name__ == "__main__":
    print("Tareas de mantenimiento")
