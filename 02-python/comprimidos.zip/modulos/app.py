# from usuario_impuestos import *
# # por lo siguiente no hay que importar con * y SIEMPRE tenemos que elegir que ncesitamos

# guardar()


# def guardar():
#     print("soy app.py")


# guardar()
# import usuarios.acciones # todo el modulo
# from usuarios import acciones # todo el paquete
# las funciones que queremos usar
from usuarios.impuestos.utilidades import pagar_impuestos
# import usuarios

pagar_impuestos()
print(__name__)
# print(usuarios.__name__)
# print(usuarios.__package__)
# print(usuarios.__path__)
# print(usuarios.__file__)
# print(usuarios.gestion.__path__)
# print(usuarios.impuestos.__path__)
