# import usuario

# def guardar():            este código es sin inyección de dependencia
#     usuario.guardar()

# def guarda(entidad):         este tiene inyección de dependencia.
#     entidad.guardar()


# def init_app(bbdd, api):
    # inicialización de modulo
